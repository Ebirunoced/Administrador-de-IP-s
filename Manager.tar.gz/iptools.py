#!/usr/bin/python

import pwd
import os
import time
import threading
import re
import glob
from iptools import IpRangeList
import sys
import re
import ctypes  # An included library with Python install.
from gi.repository import GObject
from gi.repository import Notify
PROC_TCP = "/proc/net/tcp"
STATE = {
        '01':'ESTABLISHED',
        '02':'SYN_SENT',
        '03':'SYN_RECV',
        '04':'FIN_WAIT1',
        '05':'FIN_WAIT2',
        '06':'TIME_WAIT',
        '07':'CLOSE',
        '08':'CLOSE_WAIT',
        '09':'LAST_ACK',
        '0A':'LISTEN',
        '0B':'CLOSING'
        }


def _load():
    ''' Read the table of tcp connections & remove header  '''
    with open(PROC_TCP,'r') as f:
        content = f.readlines()
        content.pop(0)
    return content

def _hex2dec(s):
    return str(int(s,16))

def _ip(s):
    ip = [(_hex2dec(s[6:8])),(_hex2dec(s[4:6])),(_hex2dec(s[2:4])),(_hex2dec(s[0:2]))]
    return '.'.join(ip)

def _remove_empty(array):
    return [x for x in array if x !='']

def _convert_ip_port(array):
    host,port = array.split(':')
    return _ip(host),_hex2dec(port)

def netstat():
    '''
    Function to return a list with status of tcp connections at linux systems
    To get pid of all network process running on system, you must run this script
    as superuser
    '''

    content=_load()
    result = []
    for line in content:
        line_array = _remove_empty(line.split(' '))     # Split lines and remove empty spaces.
        l_host,l_port = _convert_ip_port(line_array[1]) # Convert ipaddress and port from hex to decimal.
        r_host,r_port = _convert_ip_port(line_array[2]) 
        tcp_id = line_array[0]
        state = STATE[line_array[3]]
        uid = pwd.getpwuid(int(line_array[7]))[0]       # Get user from UID.
        inode = line_array[9]                           # Need the inode to get process pid.
        pid = _get_pid_of_inode(inode)                  # Get pid prom inode.
        try:                                            # try read the process name.
            exe = os.readlink('/proc/'+pid+'/exe')
        except:
            exe = None

        nline = [l_host+':'+l_port, r_host+':'+r_port]
        result.append(nline)
    return result

def _get_pid_of_inode(inode):
    '''
    To retrieve the process pid, check every running process and look for one using
    the given inode.
    '''
    for item in glob.glob('/proc/[0-9]*/fd/[0-9]*'):
        try:
            if re.search(inode,os.readlink(item)):
                return item.split('/')[2]
        except:
            pass
    return None


class MyClass(GObject.Object):
    def __init__(self):

        super(MyClass, self).__init__()
        # lets initialise with the application name
        Notify.init("myapp_name")

    def send_notification(self, title, text, file_path_to_icon=""):

        n = Notify.Notification.new(title, text, file_path_to_icon)
        n.show()



def leerFile(a): 
	
	file = open(a, "r")
	ips = []
        
         
	for text in file.readlines():
		text = text.rstrip()
        #print text
        regex = re.findall(r'(?:[\d]{1,3})\.(?:[\d]{1,3})\.(?:[\d]{1,3})\.(?:[\d]{1,3})',text)
        #print regex
        if regex is not None:
           	for match in regex:
				if match not in ips:
					ips.append(match)
					#print match
	file.close()

   	return ips



if __name__ == '__main__':
	while True:

		FILE = open("ipList","w")
		for conn in netstat():
			myvar = str(conn)
			FILE.write(myvar)
			#print conn

		FILE.close()
		ipLocal = []
		ipN = []
		ipN = leerFile("ipEvade")
		print "\n"
		ipLocal = leerFile("ipList")
		#print "matches:"
		c = list(set(ipLocal).intersection(set(ipN)))
		if not c:
			print 'Normal behavior'
		else:
			print "Spooky behavior:"
			my = MyClass()
			x = 0
			for x in range(len(c)):
				my.send_notification("Warning: ", "Spooky Connections: "+c[x])
		print c
		open('ipList','w').close()

		time.sleep(15)
def espera():
    while True:
        time.sleep(15)
        print "comprobando..."
p=threading.Thread(target = espera,)
p.setDaemon(True)
p.start()
while True: 
    pass

